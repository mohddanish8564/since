  <footer class="main-footer">

    <div class="pull-right hidden-xs">

    </div>

    <strong>Copyright &copy; <?php echo date('Y')?> <a href="#">EWS</a>.</strong> All rights reserved.

  </footer>